#!/bin/bash

# Цвета для вывода
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Функция для вывода статуса
print_status() {
    echo -e "${YELLOW}>>> $1${NC}"
}

# Функция для проверки успешности выполнения
check_status() {
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ Успешно${NC}"
    else
        echo -e "\033[0;31m✗ Ошибка: $1${NC}"
        exit 1
    fi
}

# Проверяем, что скрипт запущен от root
if [ "$EUID" -ne 0 ]; then 
    echo "Пожалуйста, запустите скрипт от имени root (используйте sudo)"
    exit 1
fi

# Получаем параметры установки
read -p "Введите имя пользователя для запуска бота: " BOT_USER
read -p "Введите путь для установки (например, /opt/telegram-bot): " INSTALL_PATH
read -p "Введите домен (например, mossport.info): " DOMAIN_NAME

# Создаем директорию установки
print_status "Создание директории установки..."
mkdir -p $INSTALL_PATH
check_status "Не удалось создать директорию"

# Устанавливаем необходимые пакеты
print_status "Установка системных зависимостей..."
apt-get update
apt-get install -y python3 python3-pip python3-venv nginx certbot python3-certbot-nginx
check_status "Не удалось установить системные пакеты"

# Создаем виртуальное окружение
print_status "Создание виртуального окружения Python..."
python3 -m venv $INSTALL_PATH/venv
source $INSTALL_PATH/venv/bin/activate
check_status "Не удалось создать виртуальное окружение"

# Устанавливаем Python зависимости
print_status "Установка Python зависимостей..."
pip install fastapi uvicorn requests python-dotenv pydantic openai google-auth google-auth-oauthlib google-auth-httplib2 google-api-python-client
check_status "Не удалось установить Python пакеты"

# Копируем файлы проекта
print_status "Копирование файлов проекта..."
cp -r ../bot $INSTALL_PATH/
cp ../.env $INSTALL_PATH/
cp -r ../credentials $INSTALL_PATH/
check_status "Не удалось скопировать файлы проекта"

# Создаем systemd сервис
print_status "Создание systemd сервиса..."
cat > /etc/systemd/system/telegram-bot.service << EOF
[Unit]
Description=Telegram Bot Webhook Service
After=network.target

[Service]
User=$BOT_USER
WorkingDirectory=$INSTALL_PATH
Environment=PATH=$INSTALL_PATH/venv/bin
ExecStart=$INSTALL_PATH/venv/bin/python bot/telegram_webhook.py
Restart=always

[Install]
WantedBy=multi-user.target
EOF
check_status "Не удалось создать systemd сервис"

# Настраиваем права доступа
print_status "Настройка прав доступа..."
chown -R $BOT_USER:$BOT_USER $INSTALL_PATH
chmod -R 755 $INSTALL_PATH
check_status "Не удалось настроить права доступа"

# Активируем и запускаем сервис
print_status "Активация и запуск сервиса..."
systemctl enable telegram-bot
systemctl start telegram-bot
check_status "Не удалось запустить сервис"

print_status "Установка SSL сертификата..."
certbot --nginx -d $DOMAIN_NAME --non-interactive --agree-tos --email admin@$DOMAIN_NAME
check_status "Не удалось установить SSL сертификат"

echo -e "${GREEN}Установка успешно завершена!${NC}"
echo -e "Проверьте работу бота: curl https://$DOMAIN_NAME/webhook/info"
