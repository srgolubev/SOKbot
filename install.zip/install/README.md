# Инструкция по установке бота

## Подготовка
1. Убедитесь, что у вас есть:
   - Доступ к серверу с root правами
   - Домен, настроенный на ваш сервер
   - Все файлы проекта в текущей директории

## Установка
1. Сделайте скрипт установки исполняемым:
```bash
chmod +x install.sh
```

2. Запустите скрипт установки:
```bash
sudo ./install.sh
```

3. Следуйте инструкциям скрипта:
   - Введите имя пользователя для запуска бота
   - Введите путь установки
   - Введите доменное имя

## Проверка установки
После установки проверьте:

1. Статус сервиса:
```bash
sudo systemctl status telegram-bot
```

2. Доступность вебхука:
```bash
curl https://ваш-домен/webhook/info
```

## Логи
Просмотр логов:
```bash
sudo journalctl -u telegram-bot -f
```

## Устранение проблем
1. Если сервис не запускается:
   ```bash
   sudo systemctl status telegram-bot
   sudo journalctl -u telegram-bot -n 50
   ```

2. Если проблемы с Nginx:
   ```bash
   sudo nginx -t
   sudo systemctl status nginx
   ```

3. Проверка SSL сертификата:
   ```bash
   certbot certificates
   ```
